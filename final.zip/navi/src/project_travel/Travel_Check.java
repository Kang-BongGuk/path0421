package project_travel;

public class Travel_Check {

	private boolean check = false;

	//�ߺ�Ȯ�ι�ư


	public boolean isCheck() {
		return check;
	}


	public void setCheck(boolean check) {
		this.check = check;
	}

	
	

}
